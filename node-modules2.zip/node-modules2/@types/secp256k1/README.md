# Installation
> `npm install --save @types/secp256k1`

# Summary
This package contains type definitions for secp256k1 (https://github.com/cryptocoinjs/secp256k1-node).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/secp256k1.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:36 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [Anler](https://github.com/anler).
