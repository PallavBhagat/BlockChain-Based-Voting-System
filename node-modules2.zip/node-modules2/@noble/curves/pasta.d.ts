export declare const p: bigint;
export declare const q: bigint;
export declare const pallas: import("./abstract/weierstrass.js").CurveFn;
export declare const vesta: import("./abstract/weierstrass.js").CurveFn;
//# sourceMappingURL=pasta.d.ts.map