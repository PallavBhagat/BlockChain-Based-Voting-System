export declare const crypto: any;
