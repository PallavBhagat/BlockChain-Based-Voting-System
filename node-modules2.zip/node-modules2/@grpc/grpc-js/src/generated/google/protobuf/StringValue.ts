// Original file: null


export interface StringValue {
  'value'?: (string);
}

export interface StringValue__Output {
  'value': (string);
}
