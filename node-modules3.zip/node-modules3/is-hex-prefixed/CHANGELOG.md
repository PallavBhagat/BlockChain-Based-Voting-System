# 0.0.1 -- is-hex-prefixed

1. Basic testing
2. Basic docs
3. License
4. linting
5. basic exports
